<footer>
        <div class="foot">
            <p class = "foottext">COS221 Practical 5<br>
            Authors: Perfect Strangers</p>
        </div>        
</footer>